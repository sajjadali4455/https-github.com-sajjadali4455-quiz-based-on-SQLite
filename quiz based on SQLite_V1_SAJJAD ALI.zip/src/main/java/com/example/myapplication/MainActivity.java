package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

import com.example.myapplication.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding binding;
    String name,age,phone,address,department;
    Student student;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        student=new Student(this);
        binding.btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name=binding.etName.getText().toString().trim();
                age=binding.etAge.getText().toString().trim();
                phone=binding.etPhone.getText().toString().trim();
                address=binding.etAddress.getText().toString().trim();
                department=binding.etDepartment.getText().toString().trim();
                student.open();
                student.createEntry(name,age,phone,address,department);
                student.close();
                Clear();


            }
        });
        binding.btnShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                student.open();
               binding.tvShow.setText(student.getData());
               student.close();
            }
        });
        binding.btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                student.open();
                student.deleteEntry("1");
                student.close();

            }
        });
        binding.btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                student.open();
                long totalupdatedRecords=student.updateEntry("1","Sajjad","15","0345789686","modelTown","CS");
                student.close();

            }
        });

    }

    private void Clear() {
        binding.etName.setText("");
        binding.etAge.setText("");
        binding.etPhone.setText("");
        binding.etAddress.setText("");
        binding.etDepartment.setText("");
    }
}