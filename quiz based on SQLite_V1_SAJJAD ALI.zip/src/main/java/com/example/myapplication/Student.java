package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.view.View;

import androidx.annotation.Nullable;

public class Student {
    public static final String KEY_ROWID="_id";
    public static final String KEY_NAME="student_name";
    public static final String KEY_AGE="_age";
    public static final String KEY_Phone="_phone";
    public static final String KEY_ADDRESS="_address";
    public static final String KEY_DEPARTMENT="_department";

    private final String DATABASE_NAME="StudentDB";
    private final String DATABASE_TABLE="StudentTable";
    private final int DATABASE_VERSION=1;

    private DBHelper ourHelper;
    private final Context ourContext;
    private SQLiteDatabase ourDatabase;

    public Student(Context ourContext) {
        this.ourContext =  ourContext;
    }

    private class DBHelper extends SQLiteOpenHelper{

        public DBHelper( Context context) {
            super(context, DATABASE_NAME,null,DATABASE_VERSION);
        }
        @Override
        public void onCreate(SQLiteDatabase db) {
            String sqlCode="CREATE TABLE "+DATABASE_TABLE+"("
                    +KEY_ROWID+"INTEGER PRIMARY KEY AUTOINCREMENT,"
                    +KEY_NAME+"TEXT NOT NULL,"
                    +KEY_AGE+"TEXT NOT NULL,"
                    +KEY_ADDRESS+"TEXT NOT NULL,"
                    +KEY_DEPARTMENT+"TEXT NOT NULL);";
            db.execSQL(sqlCode);
        }
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

            db.execSQL("DROP TABLE IF EXISTS "+DATABASE_TABLE);
            onCreate(db);
        }
    }

    public Student open()
    {
        ourHelper=new DBHelper(ourContext);
        ourDatabase=ourHelper.getWritableDatabase();
        return this;
    }

    public void close(){
        ourHelper.close();
    }
    public long createEntry(String name,String age,String phone,String address,String department){
        ContentValues cv=new ContentValues();
        cv.put(KEY_NAME,name);
        cv.put(KEY_AGE,age);
        cv.put(KEY_Phone,phone);
        cv.put(KEY_ADDRESS,address);
        cv.put(KEY_DEPARTMENT,department);
        return ourDatabase.insert(DATABASE_TABLE,null,cv);
    }
    public String getData()
    {
     String []colums=new  String[]{KEY_ROWID,KEY_NAME,KEY_AGE,KEY_Phone,KEY_ADDRESS,KEY_DEPARTMENT};
        Cursor c=ourDatabase.query(DATABASE_TABLE,colums,null,null,null,null,null);
        String result="";
        int iRowID=c.getColumnIndex(KEY_ROWID);
        int iRowName=c.getColumnIndex(KEY_NAME);
        int iRowAge=c.getColumnIndex(KEY_AGE);
        int iRowPhone=c.getColumnIndex(KEY_Phone);
        int iRowAddress=c.getColumnIndex(KEY_ADDRESS);
        int iRowDepartment=c.getColumnIndex(KEY_DEPARTMENT);

        for (c.moveToFirst();!c.isAfterLast();c.moveToNext())
        {
            result=result+c.getString(iRowID)+":"+c.getString(iRowName)+" "
                    +c.getString(iRowAge)+" "+c.getString(iRowPhone)+" "
                    +c.getString(iRowAddress)+" "+c.getString(iRowDepartment)+"\n";
        }
        c.close();
        return result;
    }
    public long updateEntry(String rowId,String name,String age,String phone,String address,String department){
        ContentValues cv=new ContentValues();
        cv.put(KEY_NAME,name);
        cv.put(KEY_AGE,age);
        cv.put(KEY_Phone,phone);
        cv.put(KEY_ADDRESS,address);
        cv.put(KEY_DEPARTMENT,department);
        return ourDatabase.update(DATABASE_TABLE,cv,KEY_ROWID+"=?",new String[]{rowId});

    }
    public long deleteEntry(String rowId){
        return ourDatabase.delete(DATABASE_TABLE,KEY_ROWID+"=?",new String[]{rowId});
    }



}
